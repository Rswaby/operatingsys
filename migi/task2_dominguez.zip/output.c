//MIGUEL DOMINGUEZ
//TASK2 
//PART 2

#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <iostream>
#include <sys/wait.h>

using std::cout;
using std::endl;
using std::string;
using namespace std;

int main (int argc, char* argv[])
{
	//parent P
	int a=10, b=25, fq=0, fr=0;
	cout<<"INITIAL (P):" << a << " " <<b <<" PID" << getpid()<<endl; //ORIGINAL VALUES

	fq=fork(); // fork a child - call it Process Q

	if(fq==0) // Child successfully forked
	{
		a=a+b;
		//print values of a, b, and process_id
		cout<<"SECOND (Q):" << a << " " <<b <<" PID" << getpid()<<endl;

		fr=fork(); // fork another child - call it Process R
		if(fr!=0)
		{
			//THis is the parent part
			b=b+20;
			//print values of a, b, and process_id
			cout<<"THIRD (Q):" << a << " " <<b <<" PID" << getpid() <<endl;
		}
		else
		{
			//THis is the child part
			a=(a*b)+30;
			//print values of a, b, and process_id
			cout<<"FORTH (R):" << a << " " <<b <<" PID" << getpid() <<endl;
		}
	}
	else
	{
		b=a+b-5;
		//print values of a, b, and process_id
		cout<<"FINAL (P):" << a << " " <<b <<" PID" << getpid() <<endl;
	}
}
