
//MIGUEL DOMINGUEZ
//TASK 2
//PART 1

#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <iostream>
#include <sys/wait.h>

using std::cout;
using std::endl;
using std::string;
using namespace std;

int main (int argc, char* argv[])
{
	int status; 
	int status2;
	int child1 = fork(); //Creates a child process based on the parent process
	//int child2 = fork(); //THis will only duplicate the parent and child one. Creating 4 processes
				//In general using fork() n times gives us 2^n processes
	if(child1 == 0)
	{
		//Here we are in the child process which was succesfully created.
		//We execute any commands until the waiting time is done and the child 
		//is terminated. 
		cout<< "Offspring 1. Pid: " << getpid() <<endl; //THis will appear second with the pid of the child
		cout<< "My root is: " <<getppid() <<endl;
		cout<<endl;
	}
	else
	{
		//THis is the parent section
		cout<<"Root here: "<<getpid() <<endl; //This statement will appear first
		cout<<endl;

	
		int endID = waitpid(child1, &status, 0);  //THis is the waiting time for the first child
		cout<<"Offspring1 terminated: " << endID <<endl; //At this point child 1 does not exist annymore
		cout<<endl;
		
		int child2 = fork(); //We fork() again to obtain a second child
		if(child2 == 0)
		{
			//THis is the body of the second child 
			cout<< "Offspring 2. Pid: " << getpid() <<endl; //This statement will appear when the second child is executed
			cout<< "My root is: " <<getppid() <<endl; //THis should be the same as the first child parent
			cout<<endl;
		}
		else
		{
			int endID2 = waitpid(child2, &status2, 0); //Waiting time for child 2
			cout<<"Offspring2 terminated: " <<endID2 <<endl; //CHild 2 terminated
			cout<<endl;
		}
		
	}

	return 0; 	
}
