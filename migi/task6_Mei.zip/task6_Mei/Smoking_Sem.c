//Sunny Mei
//sem way
#include <stdio.h>
#include<stdlib.h>
#include "sem.h"
#include <time.h>

#define PERMS 0666 

main() {
	
	// semaphores we need,
	int lock, tobacco, paper, match, agent;
	// the PID
	int pid;
	
	// lock semaphore
	if((lock=semget(IPC_PRIVATE,1,PERMS | IPC_CREAT)) == -1)
	{
	  printf("\n we can't create the semaphore");
	  exit(1);
	}

	// tobacco semaphore
	if((tobacco=semget(IPC_PRIVATE,1,PERMS | IPC_CREAT)) == -1)
	{
	  printf("\n we can't create the semaphore");
	  exit(1);
	}

	// paper semaphore
	if((paper=semget(IPC_PRIVATE,1,PERMS | IPC_CREAT)) == -1)
	{
	  printf("\n we can't create the semaphore");
	  exit(1);
	}

	// match semaphore
	if((match=semget(IPC_PRIVATE,1,PERMS | IPC_CREAT)) == -1)
	{
	  printf("\n we can't create the semaphore");
	  exit(1);
	}
	
	// agent semaphore
	if((agent=semget(IPC_PRIVATE,1,PERMS | IPC_CREAT)) == -1)
	{
	  printf("\n we can't create the semaphore");
	  exit(1);
	}
	
	// initialzing the semaphores 	
	sem_create(lock,1);
	sem_create(tobacco,0);
	sem_create(paper,0);
	sem_create(match,0);
	sem_create(agent,0);

//we fork childs for different cases when the agent wakes the smoker up.

//tobacco child 
	 if((pid=fork()) < 0)
	 {
		  printf("\n Error in process creation");
		  exit(1);
	 }
	 
    
//child tobacco - only smoke when the agent wakes him up, if not, he will sleep
//child tobacco has the tobacco, so when he wakes up, he will need match and paper.
	 if (pid == 0)
	 {
		while (1)
		{
			P(tobacco);  // Sleep right away 
			P(lock);
			//pick up match
			//pick up paper
			V(agent);
			V(lock);
			printf("smoker has tobacco. Picks up match,paper then smokes\n");
		}
	 }
	 
//paper child 
	 if((pid=fork()) < 0)
	 {
		  printf("\n Error in process creation");
		  exit(1);
	 }
    
//child paper - only smoke when the agent wakes him up, if not, he will sleep
//child paper has the paper, so when he wakes up, he will need tobacco and match.
	 if (pid == 0)
	 {
		while(1)
		{
			P(paper); //sleep right away
			P(lock);
			//picks up tobacco
			//picks up match
			V(agent);
			V(lock);
			printf("smoker has paper. Picks up match,tobacco then smokes\n");
		}
	 }
	 
//child match 
	 if((pid=fork()) < 0)
	 {
		  printf("\n Error in process creation");
		  exit(1);
	 }
	 
//child match - only smoke when the agent wakes him up, if not, he will sleep
//child match has the match, so when he wakes up, he will need tobacco and paper.
	 if (pid == 0)
	 {
		while(1)
		{
			P(match); //sleep right away
			P(lock);
			//picks up tobacco
			//picks up paper
			V(agent);
			V(lock);
			printf("smoker has match, Picks up tobacco,paper then smokes\n");
		}
	 }
	 
	 srand ( time(NULL) ); //to make rand() more random
	 int i,randNum;
	 //The agent will place materials on the table 10 times. Smoker will pick it up then pick up the rest.
	 for (i = 0; i<10; i++)
	 {
		P(lock);
		randNum = rand() % 3; // 3 different cases, agent can wake up the smoker with match, tobacco or paper. each case is random
		if (randNum == 0)//case 0, agent wakes up smoker with the match
		{
			//put tobacco on table
			//put paper on table
			printf("The agent wakes up smoker with the match\n");
			V(match); // Wake up smoker with match
		} else if (randNum == 1)//case 1, agent wakes up smoker with the paper
		{
			//put tobacco on table
			//put match on table
			printf("The agent wakes up smoker with the paper\n");
			V(paper); //wake up smoker with paper
		}
		else if(randNum == 2)//case 3, agent wakes up smoker with the tobacco
		{
			//put match on table
			//put paper on table
			printf("The agent wakes up smoker with the tobacco\n");
			V(tobacco); //wake up smoker with tobacco
		}
		V(lock);
		P(agent); //Agent sleeps
	 }
	 return 0;

}
