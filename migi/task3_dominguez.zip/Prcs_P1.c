//MIGUEL DOMINGUEZ
//TASK 3
//PART 3 CREATE DESTINATION FILES

#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <iostream>
#include <sys/wait.h>

using std::cout;
using std::endl;
using std::string;
using namespace std;

int main (int argc, char* argv[])
{
	
	int new_destination1; //Used to create new destination files
	int new_destination2;
	
	
	int filecheck1 = access("destination1.txt", F_OK); //Check if files exist already
	int filecheck2 = access("destination2.txt", F_OK);
	
	//FIRST FILE
	if (filecheck1 != 0) //FIle does not exist
	{
		new_destination1 = open("destination1.txt", O_RDWR | O_CREAT,S_IRWXU);//Create new file with proper name and permisssions
		close(new_destination1);
		cout<<"destination1.txt created!"<<endl;
	}
	else
	{
		cout<<"File destination1.txt already exists!"<<endl;
	}

	//SECOND FILE
	if(filecheck2 != 0) //File does not exist
	{
		new_destination2 = open("destination2.txt", O_RDWR | O_CREAT,S_IRWXU); //Create new file with proper name
		close(new_destination2);
		cout<<"destination2.txt created!"<<endl;
	}
	else
	{
		cout<<"File destination2.txt already exists!"<<endl;
	}

	return 0;

}
