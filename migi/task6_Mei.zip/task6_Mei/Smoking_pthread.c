//Sunny Mei
//Pthreads

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <time.h>

pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

//threads/functions
void *tobacco();
void *paper();
void *match();
void *agent();

//semaphore here
sem_t tobacco_sem;
sem_t paper_sem;
sem_t match_sem;
sem_t agent_sem;

//flag to see if agent thread ended
int flag = 1;

main()
{
	//pthreads we need
	pthread_t Tagent; //agent
	pthread_t Ttobacco; //tobacco
	pthread_t Tpaper;//paper
	pthread_t Tmatch;//match

	//return values for each thread
	int ret_agent; 
	int ret_tobacco;
	int ret_paper;
	int ret_match;
	 
	 //semephores here
	 sem_init(&tobacco_sem, 0, 0);
	 sem_init(&paper_sem, 0, 0);
	 sem_init(&match_sem, 0, 0);
	 sem_init(&agent_sem, 0, 0);

	 srand ( time(NULL) ); //to make rand() more random
	 
    // Creating the threads 
	 ret_agent = pthread_create( &Tagent, NULL, agent, NULL);
     if(ret_agent)
     {
         fprintf(stderr,"Error - pthread_create() return code: %d\n",ret_agent);
         exit(EXIT_FAILURE);
     }
	 
     ret_tobacco = pthread_create( &Ttobacco, NULL, tobacco, NULL);
     if(ret_tobacco)
     {
         fprintf(stderr,"Error - pthread_create() return code: %d\n",ret_tobacco);
         exit(EXIT_FAILURE);
     }

     ret_paper = pthread_create( &Tpaper, NULL, paper, NULL);
     if(ret_paper)
     {
         fprintf(stderr,"Error - pthread_create() return code: %d\n",ret_paper);
         exit(EXIT_FAILURE);
     }
	 
     ret_match = pthread_create( &Tmatch, NULL, match, NULL);
     if(ret_match)
     {
         fprintf(stderr,"Error - pthread_create() return code: %d\n",ret_match);
         exit(EXIT_FAILURE);
     }
	 

	 pthread_join(Tagent , NULL); 
	 
	 //when the flag is 1, which means agent thread finished, cancel the thread
	 if (flag == 0)
	 {
	 	pthread_cancel(Ttobacco);
		pthread_cancel(Tpaper);
		pthread_cancel(Tmatch);
	 }
	 
	pthread_join( Ttobacco, NULL);
	pthread_join( Tpaper, NULL); 
	pthread_join( Tmatch, NULL); 

     exit(EXIT_SUCCESS);
}


int i;
int randNum;
void *agent()
{
	//use conditional variables?
	for (i = 0; i<10; i++)
	{	
		pthread_mutex_lock(&lock);
		randNum = rand() % 3; // rand number between
		if (randNum == 0)//agent wakes smoker with match
		{
			//put tobacco on table
			//put paper on table
			printf("The agent wakes up the smoker with the match\n");
			sem_post(&match_sem); // Wake up smoker with match
		} else if (randNum == 1)//agent wakes smoker with paper
		{
			//put tobacco on table
			//put match on table
			printf("The agent wakes up the smoker with the paper\n");
			sem_post(&paper_sem); //wake up smoker with paper
		}
		else if (randNum == 2)// Wake up smoker with tobacco
		{
			//put match on table
			//put paper on table
			printf("The agent wakes up smoker with the tobacco\n");
			sem_post(&tobacco_sem); //wake up smoker with tobacco
		}
		pthread_mutex_unlock(&lock);
		sem_wait(&agent_sem); //Agent sleeps
	}
	 flag = 0; //agent has finished it's 10 materials, will change flag to 0
}


void *tobacco()
{
	while (1)
	{
		sem_wait(&tobacco_sem);  // Sleep right away
		pthread_mutex_lock(&lock);
		//pick up match
		//pick up paper
		sem_post(&agent_sem);
		pthread_mutex_unlock(&lock);
		printf("smoker with tobacco picks up match, paper then smokes\n");
	}
}


void *paper()
{
	while(1)
	{
		sem_wait(&paper_sem); //sleep right away
		pthread_mutex_lock(&lock);
		//pick up tobacco
		//pick up match
		sem_post(&agent_sem);
		pthread_mutex_unlock(&lock);
		printf("smoker with paper picks up tobacco, match then smokes\n");
	}
}


void *match()
{
	while (1)
	{
		sem_wait(&match_sem);  // Sleep right away
		pthread_mutex_lock(&lock);
		//pick up tobacco
		//pick up paper
		sem_post(&agent_sem);
		pthread_mutex_unlock(&lock);
		printf("smoker with match picks up tobacco,paper then smokes\n");
	}
}
