
//MIGUEL DOMINGUEZ
//TASK 3
//PART 1 TIME AND DATE

#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <iostream>
#include <sys/wait.h>

using std::cout;
using std::endl;
using std::string;
using namespace std;

int main (int argc, char* argv[])
{
	int offspring = fork(); //Fork child process
	int status;

	if(offspring == 0)
	{
		cout<< "Offspring 1. Pid: " << getpid() <<endl; //THis will appear second with the pid of the child

		execl("/bin/date", "date", 0, (char*) NULL); //Execute command, execute new program
		
		cout << "Offspring has failed to execl(...)" << endl; //Only printed in case execl fails
	}

	else

	{
		cout<<"Parent here: "<<getpid() <<endl; //This statement will appear first for parent

		int endID = waitpid(offspring, &status,0);

		cout<<"Offspring1 terminated: " << endID <<endl; //At this point child does not exist annymore
		cout<<endl;
	}

	return 0;

	//CAll executable as: ./part1 Give me time
}


