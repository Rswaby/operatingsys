//MIGUEL DOMINGUEZ
//TASK 3
//PART 3 COPYING TO DESTINATION FILES

#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <iostream>
#include <sys/wait.h>

using std::cout;
using std::endl;
using std::string;
using namespace std;

int main (int argc, char* argv[])
{
	int offset100s = 100; //Offset to jump to next 100 chracaters
	int offset50s = 50;   // " " 50 " "

	int openfileSource = open("source.txt", O_RDWR);    //This file will only be read
	int openfile1      = open("destination1.txt", O_WRONLY); //We will write to this file. 
	int openfile2      = open("destination2.txt", O_WRONLY); //We will write to this file. 

	int sourcesize = 1292;

	for(int i = 0; i<sourcesize; i=i+150)
	{
		string readfile = "";
		char data1[100];
		char data2[50];

		readfile = read(openfileSource, data1,100); //REad source file
		
		for(int j =0; j< 100; j++) //Look for 1's
		{
			if(data1[j] == '1')
			{
				data1[j] = 'A'; //Replace 1's with A's
			}
		}
		//cout<<data1<<endl;
		
		int copybytes = 100; 
		
		if(1292 - i > 100) //THis statement controlls whether or not we will need to handle the case when there is less than 100 chars
		{
			copybytes = 100;

		}
		else
		{
			copybytes = 1292 - i;
		} 
		

		int writefile1;
		writefile1 = write(openfile1, data1, copybytes);//Here we copy 100 characters from source files

		if(copybytes < 100)
		{
			break;
		}

		
		if(copybytes != 100)
		{
			offset100s = offset100s-100+copybytes;
 			int offset1 = lseek(openfile1,offset100s,SEEK_SET);  //We set the offset to a number less than 100
		}
		else
		{
			int offset1 = lseek(openfile1,offset100s,SEEK_SET);  //we place the offset of the file 100+ positions
		}

		
		offset100s += copybytes; //Increase offset by 100
		//cout<<offset100s<<" off"<<endl;

		//========SECOND FILE====================================================================================================

		readfile = read(openfileSource, data2,50); //REad source file
		
		for(int j =0; j< 50; j++) //Look for 1's
		{
			if(data2[j] == '2')
			{
				data2[j] = 'B'; //Replace 1's with A's
			}
		}
		//cout<<data2<<endl;
		copybytes = 50; 
		
		if(1292 - i > 50) //THis statement controlls whether or not we will need to handle the case when there is less than 100 chars
		{
			copybytes = 50;
		}
		else
		{
			copybytes = 1292 - i;
		} 
		

		int writefile2;
		writefile2 = write(openfile2, data2, copybytes);//Here we copy 50 characters from source files

		
		if(copybytes != 50)
		{
			//offset100s = offset50s-50+copybytes;
 			//int offset2 = lseek(openfile2,offset50s,SEEK_SET);  //We set the offset to a number less than 100
		}
		else
		{
			int offset2 = lseek(openfile2,offset50s,SEEK_SET);  //we place the offset of the file 100+ positions
		}

		
		offset50s += copybytes; //Increase offset by 50 for second file
		//cout<<offset50s<<" off"<<endl;
		
		cout<<"========================="<<endl;
		
	}
	
	close(openfileSource); //Close files
	close(openfile1);
	close(openfile2);

	cout<<"SUCCESFULLY COPIED, ADDED AND REPLACED TO FILE"<<endl;

	return 0;

}
